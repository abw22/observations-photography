import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Observations — Photography by Alyssa Wagnitz",
  description: "A personal photography archive about stillness, chance, and what remains.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
