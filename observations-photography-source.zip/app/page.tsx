"use client";

import { useEffect, useRef, useState } from "react";

const works = [
  { n: "01", title: "Stillness", image: "/photos/stillness.webp", note: "A quiet place holding its breath." },
  { n: "02", title: "Afterlife", image: "/photos/afterlife.webp", note: "Beauty lingers after its season." },
  { n: "03", title: "Chance", image: "/photos/chance.webp", note: "The instant before everything changes." },
];

export default function Home() {
  const [entered, setEntered] = useState(false);
  const [active, setActive] = useState(2);
  const [reveal, setReveal] = useState(48);
  const [about, setAbout] = useState(false);
  const revealRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!entered) return;
    document.getElementById("index")?.focus({ preventScroll: true });
  }, [entered]);

  const moveReveal = (clientX: number) => {
    const rect = revealRef.current?.getBoundingClientRect();
    if (rect) setReveal(Math.max(0, Math.min(100, ((clientX - rect.left) / rect.width) * 100)));
  };

  return (
    <main>
      <section className={`intro ${entered ? "intro--gone" : ""}`} aria-hidden={entered}>
        <img src="/photos/portrait.webp" alt="Portrait surrounded by fallen flower petals" />
        <div className="shade" />
        <header className="topbar topbar--light"><a href="#top">Observations</a><nav><a href="#index">Index</a><button onClick={() => setAbout(true)}>About</button></nav></header>
        <h1>The way I<br />notice things</h1>
        <button className="enter" onClick={() => setEntered(true)}>Enter <span /></button>
        <p className="frame-note">01&nbsp;&nbsp;&nbsp; Landing / First encounter</p>
      </section>

      <div className="site" id="top">
        <header className="topbar"><a href="#top">Observations</a><nav><a href="#index">Index</a><button onClick={() => setAbout(true)}>About</button></nav></header>

        <section className="index-section" id="index" tabIndex={-1}>
          <h2>Selected<br />observations</h2>
          <div className="works">
            {works.map((work, i) => (
              <button className={`work work-${i + 1}`} key={work.title} onMouseEnter={() => setActive(i)} onFocus={() => setActive(i)} onClick={() => document.getElementById("story")?.scrollIntoView({ behavior: "smooth" })}>
                <span>{work.n} / {work.title}</span>
                <img src={work.image} alt={work.note} />
                <em className={active === i ? "visible" : ""}>{work.note}</em>
              </button>
            ))}
          </div>
        </section>

        <section className="story" id="story">
          <img src={works[active].image} alt={works[active].note} />
          <div className="story-vignette" />
          <p className="story-number">{works[active].n}</p>
          <div className="story-title"><span>{works[active].n} / observation</span><h2>{works[active].title}</h2><p>{works[active].note}</p></div>
          <span className="move">Move to reveal</span>
        </section>

        <section className="reveal-section">
          <div className="reveal-copy"><span>04 / layered reveal</span><h2>What<br />remains</h2><p>Drag across the image to move between bloom and memory.</p></div>
          <div className="reveal" ref={revealRef} onPointerMove={(e) => e.buttons && moveReveal(e.clientX)} onPointerDown={(e) => { e.currentTarget.setPointerCapture(e.pointerId); moveReveal(e.clientX); }}>
            <img src="/photos/afterlife.webp" alt="Faded flowers in muted color" />
            <div className="reveal-top" style={{ clipPath: `inset(0 ${100 - reveal}% 0 0)` }}><img src="/photos/remains.webp" alt="Faded flowers in black and white" /></div>
            <span className="reveal-line" style={{ left: `${reveal}%` }}><i /></span>
          </div>
        </section>

        <section className="closer">
          <img src="/photos/closer.webp" alt="Bare branches against a cloudy sky" />
          <div className="shade" /><h2>Look<br />closer.</h2><p>Ordinary things become evidence<br />when you give them time.</p>
          <a href="#index">Return to index <span>↑</span></a>
        </section>
      </div>

      <aside className={`about ${about ? "about--open" : ""}`} aria-hidden={!about}>
        <button className="close" onClick={() => setAbout(false)} aria-label="Close about panel">×</button>
        <span>About / 2026</span><h2>Alyssa<br />Wagnitz</h2>
        <p>I am a senior at the University of Texas at Dallas, majoring in Arts, Technology, and Emerging Communication. I will graduate at the end of the summer semester.</p>
        <p className="small">My work focuses mainly on nature and still-image photography. I use the camera to slow down and highlight the quiet details, subtle changes, and ordinary moments that can otherwise go unnoticed.</p>
      </aside>
    </main>
  );
}
