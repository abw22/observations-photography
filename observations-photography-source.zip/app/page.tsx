"use client";

import { useEffect, useRef, useState } from "react";

const works = [
  { n: "01", title: "Stillness", image: "/photos/stillness.webp", note: "A quiet place holding its breath." },
  { n: "02", title: "Afterlife", image: "/photos/afterlife.webp", note: "Beauty lingers after its season." },
  { n: "03", title: "Chance", image: "/photos/chance.webp", note: "The instant before everything changes." },
];

export default function Home() {
  const [entered, setEntered] = useState(false);
  const [active, setActive] = useState(2);
  const [reveal, setReveal] = useState(48);
  const [about, setAbout] = useState(false);
  const [closerZoom, setCloserZoom] = useState(false);
  const [chanceTriggered, setChanceTriggered] = useState(false);
  const revealRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!entered) return;
    document.getElementById("index")?.focus({ preventScroll: true });
  }, [entered]);

  const moveReveal = (clientX: number) => {
    const rect = revealRef.current?.getBoundingClientRect();
    if (rect) setReveal(Math.max(0, Math.min(100, ((clientX - rect.left) / rect.width) * 100)));
  };

  return (
    <main>
      <section className={`intro ${entered ? "intro--gone" : ""}`} aria-hidden={entered}>
        <img src="/photos/portrait.webp" alt="Portrait surrounded by fallen flower petals" />
        <div className="shade" />
        <header className="topbar topbar--light"><a href="#top">Observations</a><nav><a href="#index" onClick={() => { setEntered(true); setTimeout(() => document.getElementById("index")?.scrollIntoView({ behavior:"smooth" }), 850); }}>Index</a><button onClick={() => setAbout(true)}>About</button></nav></header>
        <h1>The way I<br />notice things</h1>
        <button className="enter" onClick={() => { window.scrollTo({ top:0, behavior:"auto" }); setEntered(true); }}>Enter <span /></button>
        <p className="frame-note">01&nbsp;&nbsp;&nbsp; Landing / First encounter</p>
      </section>

      <div className="site" id="top">
        <header className="topbar"><a href="#top" onClick={(e) => { e.preventDefault(); window.scrollTo({ top:0, behavior:"smooth" }); setEntered(false); }}>Observations</a><nav><a href="#index">Index</a><button onClick={() => setAbout(true)}>About</button></nav></header>

        <section className="index-section" id="index" tabIndex={-1}>
          <h2>Selected<br />observations</h2>
          <div className="works">
            {works.map((work, i) => (
              <button className={`work work-${i + 1}`} key={work.title} onMouseEnter={() => setActive(i)} onFocus={() => setActive(i)} onClick={() => { setActive(i); document.getElementById(i === 0 ? "stillness" : i === 1 ? "afterlife" : "story")?.scrollIntoView({ behavior: "smooth" }); }}>
                <span>{work.n} / {work.title}</span>
                <img src={work.image} alt={work.note} />
                <em className={active === i ? "visible" : ""}>{work.note}</em>
              </button>
            ))}
          </div>
        </section>

        <section className="stillness-page" id="stillness" onPointerMove={(e) => { const r=e.currentTarget.getBoundingClientRect(); e.currentTarget.style.setProperty("--x",`${e.clientX-r.left}px`); e.currentTarget.style.setProperty("--y",`${e.clientY-r.top}px`); }}>
          <img src="/photos/stillness.webp" alt="Empty park bench beneath trees" />
          <img className="stillness-focus" src="/photos/stillness.webp" alt="" aria-hidden="true" />
          <div className="shade" /><div className="stillness-copy"><span>01 / observation</span><h2>Stillness</h2><p>A quiet place holding its breath.</p></div><span className="move">Move to find the stillness</span>
        </section>

        <section className={`story story--chance ${chanceTriggered ? "story--triggered" : ""}`} id="story" onClick={() => setChanceTriggered(v => !v)} onPointerMove={(e) => { const r=e.currentTarget.getBoundingClientRect(); const x=e.clientX-r.left,y=e.clientY-r.top; e.currentTarget.style.setProperty("--rx",`${(y/r.height-.5)*5}deg`); e.currentTarget.style.setProperty("--ry",`${(.5-x/r.width)*7}deg`); }}>
          <img src={works[2].image} alt={works[2].note} />
          <div className="story-vignette" />
          <p className="story-number">{works[active].n}</p>
          <div className="story-title"><span>03 / observation</span><h2>Chance</h2><p>{works[2].note}</p></div>
          <span className="move">Move to change the odds · click to {chanceTriggered ? "reset" : "set it in motion"}</span>
        </section>

        <section className="reveal-section" id="afterlife">
          <div className="reveal-copy"><span>04 / layered reveal</span><h2>What<br />remains</h2><p>Drag across the image to move between bloom and memory.</p></div>
          <div className="reveal" ref={revealRef} onPointerMove={(e) => e.buttons && moveReveal(e.clientX)} onPointerDown={(e) => { e.currentTarget.setPointerCapture(e.pointerId); moveReveal(e.clientX); }}>
            <img src="/photos/afterlife.webp" alt="Faded flowers in muted color" />
            <div className="reveal-top" style={{ clipPath: `inset(0 ${100 - reveal}% 0 0)` }}><img src="/photos/remains.webp" alt="Faded flowers in black and white" /></div>
            <span className="reveal-line" style={{ left: `${reveal}%` }}><i /></span>
          </div>
        </section>

        <section className={`closer ${closerZoom ? "closer--zoom" : ""}`} onPointerMove={(e) => { const r=e.currentTarget.getBoundingClientRect(); e.currentTarget.style.setProperty("--x",`${e.clientX-r.left}px`); e.currentTarget.style.setProperty("--y",`${e.clientY-r.top}px`); }} onClick={() => setCloserZoom(v => !v)}>
          <img src="/photos/closer.webp" alt="Bare branches against a cloudy sky" />
          <img className="closer-focus" src="/photos/closer.webp" alt="" aria-hidden="true" />
          <div className="shade" /><h2>Look<br />closer.</h2><p>Ordinary things become evidence<br />when you give them time.</p>
          <button className="closer-prompt">Move to examine · click to {closerZoom ? "step back" : "zoom in"}</button><a href="#index" onClick={(e) => e.stopPropagation()}>Return to index <span>↑</span></a>
        </section>
      </div>

      <aside className={`about ${about ? "about--open" : ""}`} aria-hidden={!about}>
        <button className="close" onClick={() => setAbout(false)} aria-label="Close about panel">×</button>
        <span>About / 2026</span><h2>Alyssa<br />Wagnitz</h2>
        <p>I am a senior at the University of Texas at Dallas, majoring in Arts, Technology, and Emerging Communication. I am graduating this semester!</p>
        <p className="small">My work focuses mainly on nature and still-image photography. I use the camera to slow down and highlight the quiet details, subtle changes, and ordinary moments that can otherwise go unnoticed.</p>
      </aside>
    </main>
  );
}
